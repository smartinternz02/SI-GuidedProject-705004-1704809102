<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_AddToCart_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>cbb8c2c3-500d-402e-9072-1b614787931c</testSuiteGuid>
   <testCaseLink>
      <guid>d24ce919-8f29-47a4-8dcf-2f8987b64129</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_AddToCart</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>be1c55e5-7de8-4464-8ff5-9d83027062c3</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_AddToCart_Excel/Amazon_Excel_AddToCart</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>be1c55e5-7de8-4464-8ff5-9d83027062c3</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>searchitem</value>
         <variableId>9fadfe88-1df9-45c3-bf03-c2e8b71d7d29</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
