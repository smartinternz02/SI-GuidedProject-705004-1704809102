<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_AddToCart_TestListener</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>fa5b1b0f-2560-4261-97c6-7e63cab2140e</testSuiteGuid>
   <testCaseLink>
      <guid>9f00c7bb-89e6-423c-a00e-d5331b35cb6b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_AddToCart</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>ee593e53-ec5b-4963-9f86-ae8fc69f24e0</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_AddToCart_Excel/Amazon_Excel_AddToCart</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>ee593e53-ec5b-4963-9f86-ae8fc69f24e0</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>searchitem</value>
         <variableId>9fadfe88-1df9-45c3-bf03-c2e8b71d7d29</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
