<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_Filter_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4a014128-f88b-47dd-a598-8bb2c75e34d1</testSuiteGuid>
   <testCaseLink>
      <guid>c57b163c-c75f-4160-80c2-e8b8f393ca7b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_Filter</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>19ddbe46-917f-490a-a3c3-fa6bfffc5707</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Filter_Excel/Amazon_Excel_Filter</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>19ddbe46-917f-490a-a3c3-fa6bfffc5707</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Filter</value>
         <variableId>68913e2c-0483-45d0-8b62-6c245f8e3d30</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
