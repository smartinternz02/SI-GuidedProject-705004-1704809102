<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_Filter_TestListener</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ea028995-06ea-422d-baa7-1c6dbb3fb910</testSuiteGuid>
   <testCaseLink>
      <guid>1fdce8ce-29be-4a7e-aaad-cc673164054e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_Filter</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>8cdcd7f5-8c85-451f-b9e6-2aca7fd93afc</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Filter_Excel/Amazon_Excel_Filter</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>8cdcd7f5-8c85-451f-b9e6-2aca7fd93afc</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Filter</value>
         <variableId>68913e2c-0483-45d0-8b62-6c245f8e3d30</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
