<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_ProductSearch_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ec8f8a85-0de2-49e8-b8e8-36875cbad1a3</testSuiteGuid>
   <testCaseLink>
      <guid>a88dddb7-bebc-4346-9f6f-6df7773269af</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_ProductSearch</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>508988a9-c7f0-4c0f-9272-acb79980a192</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_ProductSearch_Excel/Amazon_Excel_ProductSearch</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>508988a9-c7f0-4c0f-9272-acb79980a192</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>productname</value>
         <variableId>01004715-5f2d-4de6-add2-ecde1cecf287</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
