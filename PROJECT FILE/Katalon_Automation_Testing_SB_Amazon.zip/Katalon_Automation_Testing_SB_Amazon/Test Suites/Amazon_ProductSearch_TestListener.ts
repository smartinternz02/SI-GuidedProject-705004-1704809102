<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_ProductSearch_TestListener</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6584edb7-d92f-4bb8-afcf-cbd738665840</testSuiteGuid>
   <testCaseLink>
      <guid>a2d75180-d7d5-4888-91a9-1cf5c84f2958</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_ProductSearch</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>a9821aeb-16f0-4b51-b8aa-96d61cd4c38d</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_ProductSearch_Excel/Amazon_Excel_ProductSearch</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>a9821aeb-16f0-4b51-b8aa-96d61cd4c38d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>productname</value>
         <variableId>01004715-5f2d-4de6-add2-ecde1cecf287</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
