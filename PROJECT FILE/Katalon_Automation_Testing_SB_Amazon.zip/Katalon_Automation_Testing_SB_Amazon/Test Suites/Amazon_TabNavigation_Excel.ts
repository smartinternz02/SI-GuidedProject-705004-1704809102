<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_TabNavigation_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>deff9b8c-8137-4868-b031-7cbdf8d771c8</testSuiteGuid>
   <testCaseLink>
      <guid>c89b1071-ef3f-494f-a37f-9163831225d7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_TabNavigation</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>7fff3c7e-06bf-4e1a-b3d6-159db6a5c7ff</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_TabNavigation_Excel/Amazon_Excel_TabNavigation</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>7fff3c7e-06bf-4e1a-b3d6-159db6a5c7ff</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>inputproduct</value>
         <variableId>0ebf34d2-c9c0-4ca8-a6a6-878d44ddbf0c</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
