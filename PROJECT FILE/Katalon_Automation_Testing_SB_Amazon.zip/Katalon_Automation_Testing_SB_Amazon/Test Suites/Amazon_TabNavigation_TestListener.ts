<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_TabNavigation_TestListener</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>e4057439-a70b-4439-be14-03121b85a241</testSuiteGuid>
   <testCaseLink>
      <guid>14fe0afc-d027-40cf-ae5b-570323eaf47a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_TabNavigation</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>929af4ea-0b74-4a9c-af7f-ec179360709b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_TabNavigation_Excel/Amazon_Excel_TabNavigation</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>929af4ea-0b74-4a9c-af7f-ec179360709b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>inputproduct</value>
         <variableId>0ebf34d2-c9c0-4ca8-a6a6-878d44ddbf0c</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
