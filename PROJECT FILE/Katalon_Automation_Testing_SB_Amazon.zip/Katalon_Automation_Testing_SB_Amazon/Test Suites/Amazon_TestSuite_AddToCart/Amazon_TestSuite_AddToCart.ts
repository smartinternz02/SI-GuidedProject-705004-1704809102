<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_TestSuite_AddToCart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6fa980b2-068a-4c1c-bb58-08c4439b5c3d</testSuiteGuid>
   <testCaseLink>
      <guid>ddc98451-1794-4c36-9a34-176576ef3658</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/TC_Amazon_AddToCart</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>fd424b34-974e-4443-8b81-2f44aa3591ca</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_AddToCart_Excel/Amazon_Excel_AddToCart</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>fd424b34-974e-4443-8b81-2f44aa3591ca</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>searchitem</value>
         <variableId>9fadfe88-1df9-45c3-bf03-c2e8b71d7d29</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
